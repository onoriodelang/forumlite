﻿// TODO: remove me

//using System.Web.Mvc;
//using System.Web.Routing;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using OpenForum.Core;
//using OpenForum.Core.Views;

//namespace OpenForum.UnitTests
//{
//    [TestClass]
//    public class OpenForumManagerTests
//    {
//        [TestMethod]
//        public void Can_Register_Forum()
//        {
//            OpenForumManager.RegisterViewEngine();
//            Assert.AreEqual(2, ViewEngines.Engines.Count);
//            Assert.IsInstanceOfType(ViewEngines.Engines[1], typeof(DynamicViewEngine));
//        }
//    }
//}
