﻿
namespace OpenForum.Core.ViewModels.Interfaces
{
	public interface ITitledViewModel
	{
		string PageTitle { get; set; }
	}
}
